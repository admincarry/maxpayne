<?php
include("connection.php");
$delete_id = $_GET['deleteid'];
$query = "DELETE FROM `employee` WHERE `employee`.`Id` = $delete_id";
$result = mysqli_query($com, $query);
if ($result) {
   header("location:table.php");  // header and location used to go to another page 
}

?>