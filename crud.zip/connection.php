<?php

$com = mysqli_connect("localhost", "root", "", "industry");


?>