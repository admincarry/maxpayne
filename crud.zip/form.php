<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
        </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
        integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
        </script>
</head>

<body>


    <div class="container mt-5 w-50">

        <div>
            <h1 class="mb-5 text-center">Enter User Details</h1>
        </div>


        <form action="" method="post">

            <input type="text" class="form-control mb-5" name="zname" id="" placeholder="Enter Name">
            <input type="email" class="form-control mb-5" name="zemail" id="" placeholder="Enter Email">
            <input type="number" class="form-control mb-5" name="zphone" id="" placeholder="Enter Phone">
            <button type="submit" class="btn btn-danger" name="btn">Submit</button>





        </form>

    </div>

</body>

</html>

<?php







include("connection.php");

if (isset($_POST["btn"])) {
    $name = $_POST["zname"];
    $email = $_POST["zemail"];
    $phone = $_POST["zphone"];


    $insert = "INSERT INTO `employee`(`Name`, `Email`, `Phone`) VALUES ('$name','$email','$phone')";

    $run = mysqli_query($com, $insert);


}




?>